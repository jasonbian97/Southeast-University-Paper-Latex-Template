torch-vision provides DataLoaders, Pre-trained models
and common transforms for torch for images and videos

